\# 🔐 AES Encryption Tool



\## 📌 Description

A Python GUI-based tool to encrypt and decrypt files using AES-256 encryption.



\## 🚀 Features

\- File encryption with password

\- File decryption

\- Secure key generation (PBKDF2)

\- Simple GUI using Tkinter



\## ▶️ Run

```bash

python main.py

