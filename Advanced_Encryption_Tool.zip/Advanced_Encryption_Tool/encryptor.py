import os
import base64
import tkinter as tk
from tkinter import filedialog, messagebox
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet

# ---------------- KEY DERIVATION ----------------

def generate_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

# ---------------- ENCRYPT ----------------

def encrypt_file(file_path, password):
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        salt = os.urandom(16)
        key = generate_key(password, salt)
        fernet = Fernet(key)

        encrypted = fernet.encrypt(data)

        output_file = file_path + ".enc"

        with open(output_file, "wb") as f:
            f.write(salt + encrypted)

        messagebox.showinfo("Success", f"Encrypted:\n{output_file}")

    except Exception as e:
        messagebox.showerror("Error", str(e))

# ---------------- DECRYPT ----------------

def decrypt_file(file_path, password):
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        salt = data[:16]
        encrypted_data = data[16:]

        key = generate_key(password, salt)
        fernet = Fernet(key)

        decrypted = fernet.decrypt(encrypted_data)

        output_file = file_path.replace(".enc", ".dec")

        with open(output_file, "wb") as f:
            f.write(decrypted)

        messagebox.showinfo("Success", f"Decrypted:\n{output_file}")

    except Exception:
        messagebox.showerror("Error", "Wrong password or corrupted file!")

# ---------------- UI ACTIONS ----------------

def select_encrypt():
    file_path = filedialog.askopenfilename()

    password = password_entry.get()

    if not password:
        messagebox.showwarning("Warning", "Password is required!")
        return

    if file_path:
        encrypt_file(file_path, password)
        password_entry.delete(0, tk.END)  # 🔥 RESET PASSWORD

def select_decrypt():
    file_path = filedialog.askopenfilename()

    password = password_entry.get()

    if not password:
        messagebox.showwarning("Warning", "Password is required!")
        return

    if file_path:
        decrypt_file(file_path, password)
        password_entry.delete(0, tk.END)  # 🔥 RESET PASSWORD

# ---------------- GUI ----------------

app = tk.Tk()
app.title("AES-256 Encryption Tool")
app.geometry("420x280")
app.configure(bg="#1e1e2f")

title = tk.Label(app, text="🔐 Secure Encryption Tool", font=("Arial", 16, "bold"), bg="#1e1e2f", fg="white")
title.pack(pady=15)

password_label = tk.Label(app, text="Enter Password (Mandatory):", bg="#1e1e2f", fg="white")
password_label.pack()

password_entry = tk.Entry(app, show="*", width=30)
password_entry.pack(pady=5)

encrypt_btn = tk.Button(app, text="Encrypt File", command=select_encrypt, bg="green", fg="white", width=20)
encrypt_btn.pack(pady=10)

decrypt_btn = tk.Button(app, text="Decrypt File", command=select_decrypt, bg="red", fg="white", width=20)
decrypt_btn.pack(pady=10)

note = tk.Label(app, text="Password required for both operations\nPassword resets after each action", bg="#1e1e2f", fg="gray")
note.pack(side="bottom", pady=10)

app.mainloop()